package com.taskearnpro.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.util.Log;

import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.UnityAds;

public class MainActivity extends Activity implements IUnityAdsInitializationListener {

    // Unity Game ID for TaskEarnPro (Android). Taken from the Unity dashboard.
    private static final String UNITY_GAME_ID = "800394612";
    // true = Unity TEST ads (safe while testing). Set to false before you publish the app.
    private static final boolean UNITY_TEST_MODE = true;
    // Your web app
    private static final String APP_URL = "https://task-earn-pro-sand.vercel.app/";
    private static final String APP_HOST = "task-earn-pro-sand.vercel.app";

    private WebView webView;
    private FrameLayout bannerBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);   // lets tutorial / watch videos start
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri uri = Uri.parse(url);
                if (APP_HOST.equals(uri.getHost())) return false;          // stay inside the app
                startActivity(new Intent(Intent.ACTION_VIEW, uri));          // other sites open in the browser
                return true;
            }
        });

        // Banner area at the bottom (50dp), above the Unity banner
        bannerBox = new FrameLayout(this);
        bannerBox.setVisibility(android.view.View.GONE);
        int h = (int) (50 * getResources().getDisplayMetrics().density);
        FrameLayout.LayoutParams bannerLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h, Gravity.BOTTOM);

        root.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(bannerBox, bannerLp);
        setContentView(root);

        // The web app calls window.TEAndroid.showBanner(...) etc. (must be added before loadUrl)
        webView.addJavascriptInterface(new AdsBridge(this, webView, bannerBox), "TEAndroid");

        UnityAds.initialize(getApplicationContext(), UNITY_GAME_ID, UNITY_TEST_MODE, this);
        webView.loadUrl(APP_URL);
    }

    @Override
    public void onInitializationComplete() {
        Log.i("TaskEarnPro", "Unity Ads initialized");
    }

    @Override
    public void onInitializationFailed(UnityAds.UnityAdsInitializationError error, String message) {
        Log.e("TaskEarnPro", "Unity Ads init failed: " + error + " " + message);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
