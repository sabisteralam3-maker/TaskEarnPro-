package com.taskearnpro.app;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.FrameLayout;

import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsShowOptions;
import com.unity3d.services.banners.BannerErrorInfo;
import com.unity3d.services.banners.BannerView;
import com.unity3d.services.banners.UnityBannerSize;

/**
 * JavaScript bridge used by the web app:
 *   TEAndroid.showBanner("BP_Banner_Android")
 *   TEAndroid.hideBanner()
 *   TEAndroid.showRewarded("BP_Rewarded_Android")      -> window.onRewardGranted(id, true|false)
 *   TEAndroid.showInterstitial("BP_Interstitial_Android") -> window.onAdClosed(id)
 * Errors are sent to window.onAdError(id, message).
 */
public class AdsBridge {
    private final Activity activity;
    private final WebView webView;
    private final FrameLayout bannerBox;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private BannerView banner;

    public AdsBridge(Activity activity, WebView webView, FrameLayout bannerBox) {
        this.activity = activity;
        this.webView = webView;
        this.bannerBox = bannerBox;
    }

    private void js(final String code) {
        ui.post(new Runnable() {
            @Override public void run() { webView.evaluateJavascript(code, null); }
        });
    }

    private static String q(String s) {
        return "'" + String.valueOf(s).replace("\\", "\\\\").replace("'", "\\'") + "'";
    }

    // ---------------- Banner ----------------
    @JavascriptInterface
    public void showBanner(final String placementId) {
        ui.post(new Runnable() {
            @Override public void run() {
                if (banner != null) return;
                banner = new BannerView(activity, placementId, new UnityBannerSize(320, 50));
                banner.setListener(new BannerView.IListener() {
                    @Override public void onBannerLoaded(BannerView b) { js("window.onAdLoaded && window.onAdLoaded(" + q(placementId) + ")"); }
                    @Override public void onBannerFailedToLoad(BannerView b, BannerErrorInfo info) {
                        js("window.onAdError && window.onAdError(" + q(placementId) + "," + q(info == null ? "failed" : info.errorMessage) + ")");
                    }
                    @Override public void onBannerClick(BannerView b) {}
                    @Override public void onBannerLeftApplication(BannerView b) {}
                });
                bannerBox.removeAllViews();
                bannerBox.addView(banner);
                bannerBox.setVisibility(View.VISIBLE);
                banner.load();
            }
        });
    }

    @JavascriptInterface
    public void hideBanner() {
        ui.post(new Runnable() {
            @Override public void run() {
                bannerBox.removeAllViews();
                bannerBox.setVisibility(View.GONE);
                banner = null;
            }
        });
    }

    // ---------------- Rewarded / Interstitial ----------------
    @JavascriptInterface
    public void showRewarded(final String placementId) { showFull(placementId, true); }

    @JavascriptInterface
    public void showInterstitial(final String placementId) { showFull(placementId, false); }

    private void showFull(final String placementId, final boolean reward) {
        ui.post(new Runnable() {
            @Override public void run() {
                UnityAds.load(placementId, new IUnityAdsLoadListener() {
                    @Override public void onUnityAdsAdLoaded(String pid) {
                        UnityAds.show(activity, pid, new UnityAdsShowOptions(), new IUnityAdsShowListener() {
                            @Override public void onUnityAdsShowFailure(String p, UnityAds.UnityAdsShowError error, String message) {
                                js("window.onAdError && window.onAdError(" + q(p) + "," + q(message) + ")");
                                if (reward) js("window.onRewardGranted && window.onRewardGranted(" + q(p) + ",false)");
                            }
                            @Override public void onUnityAdsShowStart(String p) { js("window.onAdLoaded && window.onAdLoaded(" + q(p) + ")"); }
                            @Override public void onUnityAdsShowClick(String p) {}
                            @Override public void onUnityAdsShowComplete(String p, UnityAds.UnityAdsShowCompletionState state) {
                                boolean finished = state == UnityAds.UnityAdsShowCompletionState.COMPLETED;
                                if (reward) js("window.onRewardGranted && window.onRewardGranted(" + q(p) + "," + finished + ")");
                                else js("window.onAdClosed && window.onAdClosed(" + q(p) + ")");
                            }
                        });
                    }
                    @Override public void onUnityAdsFailedToLoad(String p, UnityAds.UnityAdsLoadError error, String message) {
                        js("window.onAdError && window.onAdError(" + q(p) + "," + q(message) + ")");
                        if (reward) js("window.onRewardGranted && window.onRewardGranted(" + q(p) + ",false)");
                    }
                });
            }
        });
    }
}
